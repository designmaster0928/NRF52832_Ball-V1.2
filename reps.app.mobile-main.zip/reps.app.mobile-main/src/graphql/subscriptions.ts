/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateUserStats = /* GraphQL */ `
  subscription OnCreateUserStats(
    $filter: ModelSubscriptionUserStatsFilterInput
    $owner: String
  ) {
    onCreateUserStats(filter: $filter, owner: $owner) {
      achievementId
      averageSpeed
      dateTime
      elapsedTime
      globalSecondaryIndex
      hand
      owner
      primarySortKey
      reps
      repTypes
      sessionTime
      speed
      statId
      timestamp
      topSpeed
      userId
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      __typename
    }
  }
`;
export const onUpdateUserStats = /* GraphQL */ `
  subscription OnUpdateUserStats(
    $filter: ModelSubscriptionUserStatsFilterInput
    $owner: String
  ) {
    onUpdateUserStats(filter: $filter, owner: $owner) {
      achievementId
      averageSpeed
      dateTime
      elapsedTime
      globalSecondaryIndex
      hand
      owner
      primarySortKey
      reps
      repTypes
      sessionTime
      speed
      statId
      timestamp
      topSpeed
      userId
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      __typename
    }
  }
`;
export const onDeleteUserStats = /* GraphQL */ `
  subscription OnDeleteUserStats(
    $filter: ModelSubscriptionUserStatsFilterInput
    $owner: String
  ) {
    onDeleteUserStats(filter: $filter, owner: $owner) {
      achievementId
      averageSpeed
      dateTime
      elapsedTime
      globalSecondaryIndex
      hand
      owner
      primarySortKey
      reps
      repTypes
      sessionTime
      speed
      statId
      timestamp
      topSpeed
      userId
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
      __typename
    }
  }
`;
