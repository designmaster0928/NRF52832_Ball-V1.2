module.exports = {
  singleQuote: true,
  trailingComma: 'all',
  endOfLine: 'auto',
};
