module.exports = {
  assets: ['./app/assets/fonts'],
  project: {
    android: {},
    ios: {},
  },
};
