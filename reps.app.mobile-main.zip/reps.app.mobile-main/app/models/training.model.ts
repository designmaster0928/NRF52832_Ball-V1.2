export interface TrainingFreestyleShots {
  statId: string;
  speed: number;
  elapsedTime: string;
}

export interface WorkoutSummaryDayValues {
  status: string;
  isToday: boolean;
}
