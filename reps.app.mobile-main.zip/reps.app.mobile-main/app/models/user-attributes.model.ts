export interface UserAttributes {
  email: string;
  firstName?: string;
  lastName?: string;
  nickname?: string;
  phone?: string;
}
