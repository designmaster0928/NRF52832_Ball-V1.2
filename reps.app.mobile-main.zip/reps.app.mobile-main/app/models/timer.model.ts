export type TimerControl = 'start' | 'pause' | 'stop';
