/* eslint-disable camelcase */
export interface CognitoUserAttributes {
  email?: string;
  family_name?: string;
  given_name?: string;
  nickname?: string;
  phone_number?: string;
}
