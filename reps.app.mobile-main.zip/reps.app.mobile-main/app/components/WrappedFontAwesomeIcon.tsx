import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { Factory } from 'native-base';

export const WrappedFontAwesomeIcon = Factory(FontAwesomeIcon);
