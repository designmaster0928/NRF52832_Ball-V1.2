/* eslint-disable @typescript-eslint/no-require-imports */
export const localImages = {
  login: require('../assets/brand/images/login-screen.png'),
  shootingFreestyle: require('../assets/brand/images/shooting-freestyle.png'),
  wallBallFreestyle: require('../assets/brand/images/wall-ball-freestyle.png'),
};
