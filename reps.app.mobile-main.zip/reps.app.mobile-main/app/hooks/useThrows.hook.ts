import { useState } from 'react';

export function useThrows() {
  const [throws, setThrows] = useState([]);
}
