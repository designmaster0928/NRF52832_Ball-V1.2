export enum WorkoutFreestyleTypes {
  WallBall = 'wall-ball', // REPS
  Shooting = 'shooting', // Throws
  Unknown = 'unknown',
}
