// export enum StorageKeys {
//   UserId = 'user.id',
//   UserStatSessionThrow = 'user.stat.session.throw',
//   BluetoothWatchedPeripherals = 'bluetooth.watched.peripherals',
// }
