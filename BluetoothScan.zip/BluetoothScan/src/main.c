
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include <zephyr/types.h>
#include <zephyr/sys/util.h>
#include <zephyr/sys/byteorder.h>
#include <zephyr/sys/reboot.h>
#include <zephyr/settings/settings.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/hci.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>

#include <nrf.h>
#include <nrf52832_peripherals.h>
#include <nrfx_clock.h>
#include <nrfx_gpiote.h>
#include <nrfx.h>
#include <nrfx_uart.h>
#include <nrfx_timer.h>
#include <nrfx_saadc.h>

#include "./user/H3LIS331DL.h"
#include "./user/nrf_delay.h"
#include "./user/FXAS21002C.h"
#include "./user/LSM6DSO.h"
#include "./user/uart.h"
#include "./user/timer.h"

#define LED1 6 //6

// --------    %%    Bluetooth Define Block    %%    ---------- // 
#define DEVICE_NAME     CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)
#define BT_UUID_CUSTOM_SERVICE_VAL \
	BT_UUID_128_ENCODE(0x1bc50001, 0x0200, 0xb8be, 0xe611, 0xe60c60b7c467)
static struct bt_uuid_128 primary_service_uuid = BT_UUID_INIT_128(BT_UUID_CUSTOM_SERVICE_VAL);
static struct bt_uuid_128 session_characteristic_uuid = BT_UUID_INIT_128(
	BT_UUID_128_ENCODE(0x1bc51100, 0x0200, 0xb8be, 0xe611, 0xe60c60b7c467));
static struct bt_uuid_128 last_shot_status_uuid = BT_UUID_INIT_128(
	BT_UUID_128_ENCODE(0x1bc51101, 0x0200, 0xb8be, 0xe611, 0xe60c60b7c467));

static bt_addr_le_t bond_addr;
static uint8_t mfg_data[] = { 0xff, 0xfe };

// ---------- Session process Block ---------- //
#define SESSION_VALUE_LEN 1
static uint32_t session_buff[SESSION_VALUE_LEN];
static ssize_t read_training_session(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			   void *buf, uint16_t len, uint16_t offset)
{
	uint32_t *value = session_buff;
	return bt_gatt_attr_read(conn, attr, buf, len, offset, session_buff, SESSION_VALUE_LEN);
}
static ssize_t write_training_session(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			    const void *buf, uint16_t len, uint16_t offset, uint8_t flags)
{
	bt_gatt_notify(NULL, attr, session_buff, SESSION_VALUE_LEN);
	return len;
}

// ---------------------- Last shot stats process Block ------------------------ //
#define SHOT_COUNT       2
#define MAX_SPEED        4
#define MAX_ACCELERATION 6
#define DURATION         8
#define FLIGHT_TIME      10
#define VAL_ACCELERATION 12
#define LAST_SHOT_STATUS_VALUE_LEN 22
static uint8_t last_shot_status_buff[LAST_SHOT_STATUS_VALUE_LEN] = {0};
static uint8_t mock_data_buff[20] = {0xfe, 0xff, 64, 0, 145, 3, 217, 2, 5, 43, 0xfe, 0xff, 64, 0, 145, 3, 217, 2, 5, 43}; //, 5, 1, 217, 2, 5, 1
static uint8_t mock_data_buff1[22] = { 254, 255, 64, 0, 145, 3, 217, 2, 5, 1, 38, 3, 0, 16, 17, 0, 16, 181, 255, 238, 137, 105 };
// ------------------------ Mock Data for testing ------------------------------ //
uint8_t shot_count_val[10] =   { 0x02, 0x05, 0x01, 0x06, 0x0d, 0x0f, 0x03, 0x04, 0x07, 0x09 };
uint8_t max_speed_val[10]  =   { 0x19, 0x13, 0x24, 0x18, 0x30, 0x0f, 0x20, 0x12, 0x28, 0x1d };
uint8_t max_accel_val[10]  =   { 0xcd, 0x6d, 0x60, 0x19, 0x4e, 0xd7, 0x21, 0xc6, 0x4f, 0xd1 };
uint8_t duration_val[10]   =   { 0x05, 0x13, 0x08, 0x0d, 0x10, 0x0f, 0x16, 0x0b, 0x11, 0x12 };
uint8_t flight_time_val[10]  = { 0x0e, 0x0d, 0x12, 0x17, 0x24, 0x19, 0x20, 0x15, 0x13, 0x0a };
uint8_t sampling_acc_val[10] = { 0x10, 0x14, 0x16, 0x0d, 0x0f, 0x11, 0x0c, 0x14, 0x12, 0x0e };
uint8_t mock_cnt = 0;
uint16_t mock_big_cnt = 0;
static ssize_t read_last_shot_status(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			   void *buf, uint16_t len, uint16_t offset)
{
	uint32_t *value = last_shot_status_buff;
	return bt_gatt_attr_read(conn, attr, buf, len, offset, value, LAST_SHOT_STATUS_VALUE_LEN);
}
static ssize_t write_last_shot_status(struct bt_conn *conn, const struct bt_gatt_attr *attr,
			    const void *buf, uint16_t len, uint16_t offset, uint8_t flags)
{
	uint32_t *value = last_shot_status_buff;
	bt_gatt_notify(NULL, attr, value, LAST_SHOT_STATUS_VALUE_LEN);
	return len;
}

BT_GATT_SERVICE_DEFINE(primary_service,
	BT_GATT_PRIMARY_SERVICE(&primary_service_uuid),
	// BT_GATT_CHARACTERISTIC(&session_characteristic_uuid.uuid,
	// 		       BT_GATT_CHRC_READ | BT_GATT_CHRC_WRITE,
	// 		       BT_GATT_PERM_READ | BT_GATT_PERM_WRITE,
	// 		       read_training_session, write_training_session, session_buff),
	BT_GATT_CHARACTERISTIC(&last_shot_status_uuid.uuid,
				   BT_GATT_CHRC_READ | BT_GATT_CHRC_WRITE,
			       BT_GATT_PERM_READ | BT_GATT_PERM_WRITE,
			       read_last_shot_status, write_last_shot_status, last_shot_status_buff),
);

static const struct bt_data ad[] = {
	BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
	BT_DATA_BYTES(BT_DATA_UUID128_ALL, BT_UUID_CUSTOM_SERVICE_VAL),
	// BT_DATA(BT_DATA_MANUFACTURER_DATA, mfg_data, sizeof(mfg_data)),
};

struct bt_le_adv_param adv_param = {
        .id = BT_ID_DEFAULT,
        .interval_min = BT_GAP_ADV_FAST_INT_MIN_2,
        .interval_max = BT_GAP_ADV_FAST_INT_MAX_2,
	    .options = BT_LE_ADV_OPT_CONNECTABLE | BT_LE_ADV_OPT_USE_NAME, //
    };

static void connected(struct bt_conn *conn, uint8_t err)
{
	if (err) {
		uart_puts("\r\nConnection failed (err 0x"); decimal_to_char(err); uart_puts(")\r\n");
	} else {
		uart_puts("\r\nConnected\r\n");
	}
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
	uart_puts("\r\nDisconnected (reason 0x"); decimal_to_char(reason); uart_puts(")\r\n");
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected = connected,
	.disconnected = disconnected
};

static void copy_last_bonded_addr(const struct bt_bond_info *info, void *data)
{
	bt_addr_le_copy(&bond_addr, &info->addr);
}

static void bt_ready(void)
{
	int err;
	char addr[BT_ADDR_LE_STR_LEN];

	uart_puts("\r\nBluetooth initialized\r\n");

	if (IS_ENABLED(CONFIG_SETTINGS)) {
		settings_load();
	}

	static const struct bt_data sd[] = {
		BT_DATA(BT_DATA_MANUFACTURER_DATA, mock_data_buff1, 22),
	};

	err = bt_le_adv_start(&adv_param, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));//&adv_param //BT_LE_ADV_CONN_NAME

	if (err) {
		uart_puts("\r\nAdvertising failed to start (err"); decimal_to_char(err); uart_puts(")\r\n");
	} else {
		uart_puts("\r\nAdvertising successfully started\r\n");
	}
}

void pairing_complete(struct bt_conn *conn, bool bonded)
{
	uart_puts("\r\nPairing completed. Rebooting in 5 seconds...\r\n");
	k_sleep(K_SECONDS(5));
	sys_reboot(SYS_REBOOT_WARM);
}

static struct bt_conn_auth_info_cb bt_conn_auth_info = {
	.pairing_complete = pairing_complete
};
// -------------------------------------------//

// --------    %%    Timer Define Block    %%    ---------- //
#define TIMER_INST_IDX   3
#define TIME_WAIT_MS     1000UL
uint32_t timer_val     = 0;
// -------------------------------------------//

// --------    %%    ADC Define Block    %%    ---------- // 
#define ADC_CHANNEL 0
nrf_saadc_value_t adc_result;
nrfx_saadc_adv_config_t saadc_adv_config = NRFX_SAADC_DEFAULT_ADV_CONFIG;
// -------------------------------------------//

// --------    %%    User Variable Define Block    %%    ---------- //
#define GYRO_THRESHOLD 54800
#define ACCELEROMETER_PEAK_FACTOR 0.5
#define MIN_SHOTS_DETECTED 10
#define DATA_BUFFER_SIZE 100
int16_t acc_x_data[DATA_BUFFER_SIZE] = {0};
int16_t acc_y_data[DATA_BUFFER_SIZE] = {0};
int16_t acc_z_data[DATA_BUFFER_SIZE] = {0};
int32_t acc_val[DATA_BUFFER_SIZE] = {0};
int16_t gyro_x_data[DATA_BUFFER_SIZE] = {0};
int16_t gyro_y_data[DATA_BUFFER_SIZE] = {0};
int16_t gyro_z_data[DATA_BUFFER_SIZE] = {0};
int32_t gyro_val[DATA_BUFFER_SIZE] = {0};
uint16_t shot_time_cnt = 0, flight_time_cnt = 0, m_time_cnt = 0, shot_cnt = 0;
uint16_t max_speed = 0;
bool shot_started = false;
bool shot_ended = false;
int shots_detected = 0;
int peak_acceleration = 0;

void led_init();
void user_timer_init();
void external_oscillator_start();
void calc_shot_status();
uint32_t findSQRT(uint64_t number);
int16_t calculate_shot_speed(int* accelerometer_data, int start_index, int end_index, uint16_t time_interval);
void shot_detect();
// -------------------------------------------//

// --------    %%   Main Function Define Block   %%    ---------- //
int main(void)
{
	external_oscillator_start();

	//uart init
	uart_init();
	uart_puts("\r\nThis is NRF52Ball test code!!\r\n");

	//Timer init
	user_timer_init();

	//led init
	led_init();

	//bluetooth init
	int err = bt_enable(NULL);
	if (err) {
		uart_puts("\r\nBluetooth init failed (err"); decimal_to_char(err); uart_puts(")\r\n");
		return 0;
	}

	const char *device_name = "nRF ball";
    err = bt_set_name(device_name);

	bt_ready();
	bt_conn_auth_info_cb_register(&bt_conn_auth_info);

	//H3LIS331DL Init
	init_h3i3(H3LIS331DL_ODR_1000Hz, H3LIS331DL_NORMAL, H3LIS331DL_FULLSCALE_2);

	uint8_t temp = 0;
	uart_puts("\r\n---SENSORS TEST START--->> ");
	//---------- H3LIS331DL test block ------------;
	uart_puts("\r\n---H3LIS331DL's WHO_AM_I--->> ");
	read_reg_h3i3(H3LIS331DL_WHO_AM_I, &temp);
	decimal_to_char(temp);
	uart_puts("\r\n");
	uart_puts("\r\n--------------------\r\n");

	//LSM6dSO Init
	init_lsm6dso();

	uart_puts("\r\n--- MEASURE START --->> ");
	while(1){
		//---------- Measure block ------------;
		// calc_shot_status();
		// nrf_delay_ms(1000);
		shot_detect();
		// m_time_cnt ++;
	}
	return 0;
}

void led_init()
{
	for(uint8_t i = 0; i < 3; i++){
		uart_puts("\r\n----- LED ON -----\r\n");
		nrf_gpio_pin_set(LED1);   nrf_delay_ms(4000);
		uart_puts("\r\n----- LED OFF -----\r\n");
		nrf_gpio_pin_clear(LED1); nrf_delay_ms(4000);
	} 
	uart_puts("\r\n----- LED ON -----\r\n");
	nrf_gpio_pin_set(LED1);
}

void external_oscillator_start()
{
	// Use the external crystal oscillator as the system clock source
    NRF_CLOCK->TASKS_HFCLKSTOP = 1;
    NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;
	NRF_CLOCK->TASKS_HFCLKSTART = 1;
    while (NRF_CLOCK->EVENTS_HFCLKSTARTED == 0) {
        // Wait for the system clock to switch to the external crystal oscillator
    }
}

void user_timer_handler(nrf_timer_event_t event_type, void * p_context)
{
    nrfx_timer_t * timer_inst = p_context;
	timer_val ++;
	uart_puts("\r\n--Timer--\r\n");
	
}

void user_timer_init()
{
	uart_puts("\r\n----- Timer Init Start -----\r\n");
	nrfx_timer_t timer_inst = NRFX_TIMER_INSTANCE(TIMER_INST_IDX);
    nrfx_timer_config_t config = NRFX_TIMER_DEFAULT_CONFIG;
    config.bit_width = NRF_TIMER_BIT_WIDTH_32;
    config.p_context = &timer_inst;
    nrfx_err_t status = nrfx_timer_init(&timer_inst, &config, user_timer_handler);
    // NRFX_ASSERT(status == NRFX_SUCCESS);

	#define TIMER_INST         NRFX_CONCAT_2(NRF_TIMER, TIMER_INST_IDX)
    #define TIMER_INST_HANDLER NRFX_CONCAT_3(nrfx_timer_, TIMER_INST_IDX, _irq_handler)
    IRQ_DIRECT_CONNECT(NRFX_IRQ_NUMBER_GET(TIMER_INST), IRQ_PRIO_LOWEST, TIMER_INST_HANDLER, 0);

	uint32_t desired_ticks = nrfx_timer_ms_to_ticks(&timer_inst, TIME_WAIT_MS);
    nrfx_timer_extended_compare(&timer_inst, NRF_TIMER_CC_CHANNEL0, desired_ticks,
                                NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);
	nrfx_timer_enable(&timer_inst);
	nrfx_timer_is_enabled(&timer_inst) ? uart_puts("\r\n----- Timer enabled -----\r\n") : uart_puts("\r\n----- Timer disabled -----\r\n");

}

void saadc_handler(nrfx_saadc_evt_t const * p_event)
{
    if (p_event->type == NRFX_SAADC_EVT_DONE)
    {
        adc_result = p_event->data.done.p_buffer[0];
    }
}

void saadc_init(void)
{
   
}

void calc_shot_status(){
    AxesRaw_t data;
    int32_t sum[6] = {0}, max_acc = 0;
	status_t response = get_acc_axes_raw_h3i3(&data);
	
	for (int i = 0 ; i < DATA_BUFFER_SIZE - 1; i++) {
		acc_x_data[i] = acc_x_data[i + 1];   
		acc_y_data[i] = acc_y_data[i + 1];
		acc_z_data[i] = acc_z_data[i + 1];
		acc_val[i] = acc_val[i+1];
		gyro_x_data[i] = gyro_x_data[i + 1]; 
		gyro_y_data[i] = gyro_y_data[i + 1]; 
		gyro_z_data[i] = gyro_z_data[i + 1]; 
		gyro_val[i] = gyro_val[i+1];      
		sum[0] += acc_x_data[i];
		sum[1] += acc_y_data[i];
		sum[2] += acc_z_data[i];
		sum[3] += gyro_x_data[i];
		sum[4] += gyro_y_data[i];
		sum[5] += gyro_z_data[i];
		if( max_acc < acc_val[i] ) max_acc = acc_val[i];
		//if( i % 10 == 0 ) last_shot_status_buff[VAL_ACCELERATION + i/10] = acc_val[i] % 256;
	}
	if (MEMS_SUCCESS == response) {
		acc_x_data[DATA_BUFFER_SIZE - 1] = data.AXIS_X;
		acc_y_data[DATA_BUFFER_SIZE - 1] = data.AXIS_Y;
		acc_z_data[DATA_BUFFER_SIZE - 1] = data.AXIS_Z;
		gyro_x_data[DATA_BUFFER_SIZE - 1] = read_raw_gyro_x_lsm6dso();
		gyro_y_data[DATA_BUFFER_SIZE - 1] = read_raw_gyro_y_lsm6dso();
		gyro_z_data[DATA_BUFFER_SIZE - 1] = read_raw_gyro_z_lsm6dso();
	}
	sum[0] += acc_x_data[DATA_BUFFER_SIZE - 1];
	sum[1] += acc_y_data[DATA_BUFFER_SIZE - 1];
	sum[2] += acc_z_data[DATA_BUFFER_SIZE - 1];
	sum[3] += gyro_x_data[DATA_BUFFER_SIZE - 1];
	sum[4] += gyro_y_data[DATA_BUFFER_SIZE - 1];
	sum[5] += gyro_z_data[DATA_BUFFER_SIZE - 1];
	int32_t axis_x = sum[0] * 3 / DATA_BUFFER_SIZE;
	int32_t axis_y = sum[1] * 3 / DATA_BUFFER_SIZE;
	int32_t axis_z = sum[2] * 3 / DATA_BUFFER_SIZE;
	int16_t gyro_x = sum[3] / DATA_BUFFER_SIZE;
	int16_t gyro_y = sum[4] / DATA_BUFFER_SIZE;
	int16_t gyro_z = sum[5] / DATA_BUFFER_SIZE;
	acc_val[DATA_BUFFER_SIZE - 1]  = findSQRT(axis_x * axis_x  + axis_y * axis_y + axis_z * axis_z);
	gyro_val[DATA_BUFFER_SIZE - 1] = findSQRT(gyro_x * gyro_x  + gyro_y * gyro_y + gyro_z * gyro_z);
	uart_puts("\r\n--- ACCELERO -> ");  decimal_to_char(axis_x); uart_puts(", "); decimal_to_char(axis_y); uart_puts(", "); decimal_to_char(axis_z); uart_puts(", "); decimal_to_char(acc_val[DATA_BUFFER_SIZE - 1]);  uart_puts("\r\n");
	uart_puts("\r\n--- GYROSCOPE -> "); decimal_to_char(gyro_x); uart_puts(", "); decimal_to_char(gyro_y); uart_puts(", "); decimal_to_char(gyro_z); uart_puts(", "); decimal_to_char(gyro_val[DATA_BUFFER_SIZE - 1]); uart_puts("\r\n");
	//last_shot_status_buff[MAX_ACCELERATION] = max_acc % 256; last_shot_status_buff[MAX_ACCELERATION + 1] = max_acc / 256;
	uint16_t m_speed = calculate_shot_speed(acc_val,0, DATA_BUFFER_SIZE-1, 10);
	if( max_speed < m_speed ) max_speed = m_speed; 
	//last_shot_status_buff[MAX_SPEED] = max_speed % 256; last_shot_status_buff[MAX_SPEED + 1] = max_speed / 256; 
	//-------- SHOT DETECT PROCESS ---------//
	if (gyro_val[DATA_BUFFER_SIZE - 1] > GYRO_THRESHOLD) shots_detected++;
	if (shots_detected >= MIN_SHOTS_DETECTED && !shot_started) {
		shot_started = true;
		peak_acceleration = ( acc_val[DATA_BUFFER_SIZE - 2] > acc_val[DATA_BUFFER_SIZE - 1] ) ? acc_val[DATA_BUFFER_SIZE - 2] : acc_val[DATA_BUFFER_SIZE - 1];
	}
	if (shot_started && acc_val[DATA_BUFFER_SIZE - 1] < peak_acceleration * ACCELEROMETER_PEAK_FACTOR) {
		shot_ended = true; shot_started = false;
	}
}

uint32_t findSQRT(uint64_t number)
{
    uint64_t start = 0, end = number;
    uint64_t mid;
    uint32_t ans;
    while (start <= end) {
        mid = (start + end) / 2;
        if (mid * mid == number) {
            ans = mid; break;
        }
        if (mid * mid < number) { 
            ans = start;
            start = mid + 1;
        }
        else end = mid - 1;
    }
    return ans;
}

int16_t calculate_shot_speed(int* accelerometer_data, int start_index, int end_index, uint16_t time_interval) {
    int16_t velocity = 0.0;
    int16_t acceleration_sum = 0.0;
    for (int i = start_index; i <= end_index; i++) {
        acceleration_sum += accelerometer_data[i];
        velocity += acceleration_sum * time_interval;
    }
    velocity /= (end_index - start_index + 1);
    return velocity;
}

void shot_detect(){
	// if( shot_started ) shot_time_cnt ++;
	// if( shot_ended ) {
	// 	shot_cnt ++;
	// 	last_shot_status_buff[DURATION]       = shot_time_cnt % 256;
	// 	last_shot_status_buff[DURATION + 1]   = shot_time_cnt / 256;
	// 	last_shot_status_buff[SHOT_COUNT]     = shot_cnt      % 256;
	// 	last_shot_status_buff[SHOT_COUNT + 1] = shot_cnt      / 256;
	// }
	if( !timer_val ) return;
	timer_val = 0;
	mock_data_buff1[2] ++;
	static const struct bt_data sd[] = {
		BT_DATA(BT_DATA_MANUFACTURER_DATA, mock_data_buff1, 22),
	};
	
	bt_le_adv_update_data(ad, ARRAY_SIZE(ad),
                              sd, ARRAY_SIZE(sd));
	// mock_big_cnt ++;
	// if( mock_big_cnt == 20 ) {
	// 	mock_big_cnt = 0;
	// 	mock_cnt ++;
	// 	if( mock_cnt == 10 ) mock_cnt = 0;
	// 	last_shot_status_buff[0] = 0xff;
	// 	last_shot_status_buff[1] = 0xfe;
	// 	last_shot_status_buff[ SHOT_COUNT ]  = shot_count_val[mock_cnt];
	// 	last_shot_status_buff[ MAX_SPEED ]   = max_speed_val[mock_cnt];
	// 	last_shot_status_buff[ DURATION ]    = duration_val[mock_cnt];
	// 	last_shot_status_buff[ FLIGHT_TIME ] = flight_time_val[mock_cnt];
	// 	last_shot_status_buff[ MAX_ACCELERATION ] = max_accel_val[mock_cnt];
	// 	last_shot_status_buff[ VAL_ACCELERATION ] = sampling_acc_val[mock_cnt];
	// }
}

