#ifndef NRF_CALENDAR_H
#define NRF_CALENDAR_H

#include <stdint.h>
#include <stdbool.h>
#include <time.h>

#ifdef	__cplusplus
extern "C" {
#endif

    // Change the following defines to change the RTC timer used or the interrupt priority
    #define CAL_RTC                 NRF_RTC0
    #define CAL_RTC_IRQn            RTC0_IRQn
    #define CAL_RTC_IRQHandler      RTC0_IRQHandler
    #define CAL_RTC_IRQ_Priority    3

    void nrf_cal_init(void);

    void nrf_cal_set_callback(void (*callback)(void), uint32_t interval);

    void nrf_cal_set_time(uint32_t year, uint32_t month, uint32_t day, uint32_t hour, uint32_t minute, uint32_t second);

    struct tm *nrf_cal_get_time(void);

    struct tm *nrf_cal_get_time_calibrated(void);

    char *nrf_cal_get_time_string(bool calibrated);

    time_t get_time(void);
    time_t time(time_t *tloc);

#ifdef	__cplusplus
}
#endif

#endif /* NRF_CALENDAR_H */