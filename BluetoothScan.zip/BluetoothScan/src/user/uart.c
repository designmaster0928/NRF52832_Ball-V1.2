#include "uart.h"

void uart_init(void)
{
	nrf_uart_configure(UART_INSTANCE, NRF_UART_PARITY_INCLUDED);
	nrf_uart_baudrate_set(UART_INSTANCE, NRF_UART_BAUDRATE_9600);
    nrf_uart_txrx_pins_set(UART_INSTANCE, 3, 4);
	nrf_uart_enable(UART_INSTANCE);
	nrf_uart_task_trigger(UART_INSTANCE, NRF_UART_TASK_STARTTX);
	nrf_uart_task_trigger(UART_INSTANCE, NRF_UART_TASK_STARTRX);
}

void uart_putchar(uint8_t ch)
{
	nrf_uart_txd_set(UART_INSTANCE,ch);
	while(!nrf_uart_event_check(UART_INSTANCE,NRF_UART_EVENT_TXDRDY));
	nrf_uart_event_clear(UART_INSTANCE,NRF_UART_EVENT_TXDRDY);
}

uint8_t uart_getchar(void)
{
	while(!nrf_uart_event_check(UART_INSTANCE,NRF_UART_EVENT_RXDRDY));
	nrf_uart_event_clear(UART_INSTANCE,NRF_UART_EVENT_RXDRDY);
	return nrf_uart_rxd_get(UART_INSTANCE);
}

void uart_puts(uint8_t * str)
{
	while(*str!='\0')
	{
		uart_putchar(*str);
		str++;
	}
}

void uart_gets(uint8_t * buf,int len)
{
	while(len)
	{
		*buf=uart_getchar();
		len--;
		buf++;
	}
	*buf='\0';
}

void decimal_to_char( int32_t decimal ){
	uint8_t num[10], cnt = 0;
	int32_t temp = decimal;
	if( temp == 0 ) { num[0] = 0; cnt = 1; }
	else {
		if( temp<0 ) { temp = 0 - temp; uart_puts("-"); }
		while(temp>0) { num[cnt++] = temp % 10; temp = temp / 10; }
	}
	for( int i = cnt; i > 0; i-- ){
		switch(num[i-1]){
			case 0: uart_puts("0"); break; case 1: uart_puts("1"); break; case 2: uart_puts("2"); break; case 3: uart_puts("3"); break;
			case 4: uart_puts("4"); break; case 5: uart_puts("5"); break; case 6: uart_puts("6"); break; case 7: uart_puts("7"); break;
			case 8: uart_puts("8"); break; case 9: uart_puts("9"); break;
		}
	}
}
