
#include "FXAS21002C.h"
#include "nrf_delay.h"
#include <nrfx_gpiote.h>

// Sensor address
byte address;
// Sensor data
SRAWDATA gyroData; // RAW acceleration sensor data
int8_t tempData; // RAW temperature data
// Sensor configuration
uint8_t gyroFSR;
uint8_t gyroODR;
float gRes, gBias[3] = {0, 0, 0}; // scale resolutions per LSB for the sensors

void init_fs21002() {
    gyroFSR = GFS_250DPS;
    gyroODR = GODR_800HZ;

    // ------- I2C configuration2 --------------
    nrfx_spi_config_t spi_config;
    spi_config.ss_pin = FXAS21002C_SPI_SS_PIN;
    spi_config.miso_pin = FXAS21002C_SPI_MISO_PIN;
    spi_config.mosi_pin = FXAS21002C_SPI_MOSI_PIN;
    spi_config.sck_pin = FXAS21002C_SPI_SCK_PIN;
    spi_config.irq_priority = NRFX_SPI_DEFAULT_CONFIG_IRQ_PRIORITY,
    spi_config.orc = 0xFF,
    spi_config.frequency = NRF_SPI_FREQ_1M;
    spi_config.mode = NRF_SPI_MODE_0;
    spi_config.bit_order = NRF_SPI_BIT_ORDER_MSB_FIRST;
    spi_config.skip_psel_cfg = false;
    spi_config.skip_gpio_cfg = false;
    nrfx_err_t err_code = nrfx_spi_init(&m_spi_fs21002, &spi_config, NULL, NULL);
	//NRFX_CHECK(err_code);

    standby_fs21002();  // Must be in standby to change registers

	// Set up the full scale range to 250, 500, 1000, or 2000 deg/s.

	write_reg_fs21002(FXAS21002C_CTRL_REG0, GFS_2000DPS);
	 // Setup the 3 data rate bits, 4:2
    write_reg_fs21002(FXAS21002C_CTRL_REG1, gyroODR);   
	// Disable FIFO, route FIFO and rate threshold interrupts to INT2, enable data ready interrupt, route to INT1
  	// Active HIGH, push-pull output driver on interrupts
  	write_reg_fs21002(FXAS21002C_CTRL_REG2, 0x0E);

  	 // Set up rate threshold detection; at max rate threshold = FSR; rate threshold = THS*FSR/128
  	write_reg_fs21002(FXAS21002C_RT_CFG, 0x07);         // enable rate threshold detection on all axes
  	write_reg_fs21002(FXAS21002C_RT_THS, 0x00 | 0x0D);  // unsigned 7-bit THS, set to one-tenth FSR; set clearing debounce counter
  	write_reg_fs21002(FXAS21002C_RT_COUNT, 0x04);       // set to 4 (can set up to 255)         
	// Configure interrupts 1 and 2
	write_reg_fs21002(FXAS21002C_CTRL_REG3, 0x00); // clear bits 0, 1 
	//writeReg(CTRL_REG3, readReg(CTRL_REG3) |  (0x02)); // select ACTIVE HIGH, push-pull interrupts    
	//writeReg(CTRL_REG4, readReg(CTRL_REG4) & ~(0x1D)); // clear bits 0, 3, and 4
	//writeReg(CTRL_REG4, readReg(CTRL_REG4) |  (0x1D)); // DRDY, Freefall/Motion, P/L and tap ints enabled  
	//writeReg(CTRL_REG5, 0x01);  // DRDY on INT1, P/L and taps on INT2
	active_fs21002();  // Set to active to start reading
}

void write_reg_fs21002(byte reg, byte value) {
    // ------------- SPI Process1 --------------    
    uint8_t tx_buf[2] = { reg, value };
    nrfx_spi_xfer_desc_t spi_xfer_desc = NRFX_SPI_XFER_TX(tx_buf, 2);
    nrfx_err_t status = nrfx_spi_xfer(&m_spi_fs21002, &spi_xfer_desc, 0);
    //NRFX_ASSERT(status == NRFX_SUCCESS);
}
    
// Reads a register
byte read_reg_fs21002(byte reg) {
    // ------------- SPI Process1 --------------
    uint8_t tx_buf[2] = { reg | 0x80, 0x00 };
    uint8_t rx_buf[2];
    nrfx_spi_xfer_desc_t spi_xfer_desc = NRFX_SPI_XFER_TRX(tx_buf, 2, rx_buf, 2);
    nrfx_err_t status = nrfx_spi_xfer(&m_spi_fs21002, &spi_xfer_desc, 0);
    return rx_buf[1];
}

void read_regs_fs21002(byte reg, uint8_t count, byte dest[]) {
    // ------------- SPI Process1 --------------
    uint8_t tx_buf[2] = { reg | 0x80, 0x00 };
    nrfx_spi_xfer_desc_t spi_xfer_desc = NRFX_SPI_XFER_TRX(tx_buf, 2, dest, count + 1);
    nrfx_err_t status = nrfx_spi_xfer(&m_spi_fs21002, &spi_xfer_desc, 0);
}

// Read the temperature data
void read_temp_data_fs21002()
{
	tempData = read_reg_fs21002(FXAS21002C_TEMP);
}

// Put the FXAS21002C into standby mode.
// It must be in standby for modifying most registers
void standby_fs21002()
{
	byte c = read_reg_fs21002(FXAS21002C_CTRL_REG1);
	write_reg_fs21002(FXAS21002C_CTRL_REG1, c & ~(0x03));// Clear bits 0 and 1; standby mode
}
// Sets the FXAS21000 to active mode.
// Needs to be in this mode to output data
void ready_fs21002()
{
  byte c = read_reg_fs21002(FXAS21002C_CTRL_REG1);
  write_reg_fs21002(FXAS21002C_CTRL_REG1, c & ~(0x03));  // Clear bits 0 and 1; standby mode
  write_reg_fs21002(FXAS21002C_CTRL_REG1, c |   0x01);   // Set bit 0 to 1, ready mode; no data acquisition yet
}

// Put the FXAS21002C into active mode.
// Needs to be in this mode to output data.
void active_fs21002()
{
	byte c = read_reg_fs21002(FXAS21002C_CTRL_REG1);
	write_reg_fs21002(FXAS21002C_CTRL_REG1, c & ~(0x03));  // Clear bits 0 and 1; standby mode
  	write_reg_fs21002(FXAS21002C_CTRL_REG1, c |   0x02);   // Set bit 1 to 1, active mode; data acquisition enabled
}

// Read the gyroscope data
void read_gyro_data_fs21002()
{
	uint8_t rawData[6];  // x/y/z gyro register data stored here
	read_regs_fs21002(FXAS21002C_OUT_X_MSB, 6, &rawData[0]);  // Read the six raw data registers into data array
	gyroData.x = ((int16_t)(((int16_t)rawData[0]) << 8 | ((int16_t) rawData[1])));
	gyroData.y = ((int16_t)(((int16_t)rawData[2]) << 8 | ((int16_t) rawData[3])));
	gyroData.z = ((int16_t)(((int16_t)rawData[4]) << 8 | ((int16_t) rawData[5])));
}

// Get accelerometer resolution
float get_gres_fs21002(void)
{
	switch (gyroFSR)
	{
		// Possible gyro scales (and their register bit settings) are:
  // 250 DPS (11), 500 DPS (10), 1000 DPS (01), and 2000 DPS  (00). 
    case GFS_2000DPS:
          return 2000.0/16384.0;
    case GFS_1000DPS:
          return 1000.0/16384.0;
    case GFS_500DPS:
          return 500.0/16384.0;       
    case GFS_250DPS:
          return 250.0/16384.0;
	}
}

void calibrate_fs21002(float * gBias)
{
    int32_t gyro_bias[3] = {0, 0, 0};
    uint16_t ii, fcount;
    int16_t temp[3];
    
    // Clear all interrupts by reading the data output and STATUS registers
    //readGyroData(temp);
    read_reg_fs21002(FXAS21002C_STATUS);
    
    standby_fs21002();  // Must be in standby to change registers

    write_reg_fs21002(FXAS21002C_CTRL_REG1, 0x08);   // select 50 Hz ODR
    fcount = 50;                                     // sample for 1 second
    write_reg_fs21002(FXAS21002C_CTRL_REG0, 0x03);   // select 200 deg/s full scale
    float gyrosensitivity = 32000.0/250.0; //GFS_250DPS;

    active_fs21002();  // Set to active to start collecting data
    
    uint8_t rawData[6];  // x/y/z FIFO accel data stored here
    for(ii = 0; ii < fcount; ii++)   // construct count sums for each axis
    {
        read_regs_fs21002(FXAS21002C_OUT_X_MSB, 6, &rawData[0]);  // Read the FIFO data registers into data array
        temp[0] = ((int16_t)( ((int16_t) rawData[0]) << 8 | ((int16_t) rawData[1])));
        temp[1] = ((int16_t)( ((int16_t) rawData[2]) << 8 | ((int16_t) rawData[3])));
        temp[2] = ((int16_t)( ((int16_t) rawData[4]) << 8 | ((int16_t) rawData[5])));
        
        gyro_bias[0] += (int32_t) temp[0];
        gyro_bias[1] += (int32_t) temp[1];
        gyro_bias[2] += (int32_t) temp[2];
        
        nrf_delay_us(25); // wait for next data sample at 50 Hz rate
    }
    
    gyro_bias[0] /= (int32_t) fcount; // get average values
    gyro_bias[1] /= (int32_t) fcount;
    gyro_bias[2] /= (int32_t) fcount;
    
    gBias[0] = (float)gyro_bias[0]/(float) gyrosensitivity; // get average values
    gBias[1] = (float)gyro_bias[1]/(float) gyrosensitivity; // get average values
    gBias[2] = (float)gyro_bias[2]/(float) gyrosensitivity; // get average values

    ready_fs21002();  // Set to ready
}

void reset_fs21002() 
{
	write_reg_fs21002(FXAS21002C_CTRL_REG1, 0x20); // set reset bit to 1 to assert software reset to zero at end of boot process
	nrf_delay_us(100);
    while(!(read_reg_fs21002(FXAS21002C_INT_SRC_FLAG) & 0x08))  { // wait for boot end flag to be set
    }
}


