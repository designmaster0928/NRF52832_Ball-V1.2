#include <nrf.h>
#include "nrf_delay.h"

void nrf_delay_us(uint32_t number_of_us)
{
    // The loop takes 5 cycles per iteration
    // Each iteration is 3 instructions
    // 1 cycle for overhead (r0-r1-r2)
    // 1 cycle for ldr r2, [r2, #0]
    // 1 cycle for subs r0, r0, #1
    while (number_of_us--)
    {
        __ASM volatile("NOP");
        __ASM volatile("NOP");
        __ASM volatile("NOP");
        __ASM volatile("NOP");
        __ASM volatile("NOP");
        __ASM volatile("NOP");
        __ASM volatile("NOP");
        __ASM volatile("NOP");
    }
}

void nrf_delay_ms(uint32_t number_of_ms)
{
    while (number_of_ms--)
    {
        nrf_delay_us(1000);
    }
}