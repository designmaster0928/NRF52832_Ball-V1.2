#include <stdint.h>
#include <nrf.h>
//#include <nrf_gpio.h>
#include <nrfx_twi.h>
#include <nrfx_spi.h>

#ifndef FXAS21002C_H_
#define FXAS21002C_H_

#ifdef __cplusplus
extern "C" {
#endif
   
     // SPI instance
    #define FXAS21002C_SPI_INSTANCE NRF_SPI2
    static const nrfx_spi_t m_spi_fs21002 = NRFX_SPI_INSTANCE(2); 
   
    // SPI pins
    #define FXAS21002C_SPI_MOSI_PIN   19
    #define FXAS21002C_SPI_MISO_PIN   18
    #define FXAS21002C_SPI_SCK_PIN    20
    #define FXAS21002C_SPI_SS_PIN     17

    // I2C ADDRESS
    #define FXAS21002C_I2C_ADDRESS          0x20//( SA0 connected GND ), 0x21( SA0 connected VDD )
    #define FXAS21002C_I2C_READ_ADDRESS     0x41//( SA0 connected GND ), 0x43( SA0 connected VDD )
    #define FXAS21002C_I2C_WRITE_ADDRESS    0x40//( SA0 connected GND ), 0x42( SA0 connected VDD )

    // I2C instance
    #define FXAS21002C_I2C_INSTANCE  NRF_TWI1
    static const nrfx_twi_t m_i2c_fs21002 = NRFX_TWI_INSTANCE(0);

    // I2C pins
    #define FXAS21002C_I2C_SA0_PIN   18
    #define FXAS21002C_I2C_SCL_PIN   20
    #define FXAS21002C_I2C_SDA_PIN   19
    #define FXAS21002C_I2C_CS_PIN    17

    // register addresses FXAS21002C_
    #define FXAS21002C_STATUS           0x00
    #define FXAS21002C_DR_STATUS        0x07
    #define FXAS21002C_F_STATUS         0x08
    #define FXAS21002C_OUT_X_MSB        0x01    
    #define FXAS21002C_OUT_X_LSB        0x02
    #define FXAS21002C_OUT_Y_MSB        0x03
    #define FXAS21002C_OUT_Y_LSB        0x04
    #define FXAS21002C_OUT_Z_MSB        0x05
    #define FXAS21002C_OUT_Z_LSB        0x06
    #define FXAS21002C_F_SETUP          0x09
    #define FXAS21002C_F_EVENT          0x0A
    #define FXAS21002C_INT_SRC_FLAG     0x0B
    #define FXAS21002C_WHO_AM_I         0x0C
    #define FXAS21002C_CTRL_REG0        0x0D  
    #define FXAS21002C_RT_CFG       	  0x0E
    #define FXAS21002C_RT_SRC       	  0x0F 
    #define FXAS21002C_RT_THS       	  0x10
    #define FXAS21002C_RT_COUNT         0x11
    #define FXAS21002C_TEMP             0x12
    #define FXAS21002C_CTRL_REG1        0x13
    #define FXAS21002C_CTRL_REG2        0x14
    #define FXAS21002C_CTRL_REG3        0x15

    enum GyroODR {
        GODR_800HZ = 0, // 200 Hz
        GODR_400HZ,
        GODR_200HZ,
        GODR_100HZ,
        GODR_50HZ,
        GODR_12_5HZ, // 12.5 Hz, etc.
        GODR_6_25HZ,
        GODR_1_56HZ
    };

    // Set initial input parameters
    enum gyroFSR {
        GFS_2000DPS = 0,
        GFS_1000DPS,
        GFS_500DPS,
        GFS_250DPS
    };

	typedef struct 
	{
	    int16_t	x;
	    int16_t	y;
	    int16_t	z;
	} SRAWDATA;

    typedef uint8_t byte;

	// Register functions
	void write_reg_fs21002(byte reg, byte value);
	byte read_reg_fs21002(byte reg);
	void read_regs_fs21002(byte startReg, uint8_t count, byte dest[]);

	// FXAS21002C functions
	// Initialization & Termination
	void init_fs21002(void);
	void standby_fs21002(void);
	void active_fs21002(void);
	void ready_fs21002(void);

	// Query sensor data
	void read_gyro_data_fs21002(void);
	void read_temp_data_fs21002(void);

	// Resolution
	float get_gres_fs21002(void);

	//Calibrate
	void calibrate_fs21002(float * gBias);

	//Reset
	void reset_fs21002(void);

	// Sensor address
	extern byte address;
    // Sensor data
	extern SRAWDATA gyroData; // RAW acceleration sensor data
	extern int8_t tempData; // RAW temperature data

	// Sensor configuration
	extern uint8_t gyroFSR;
	extern uint8_t gyroODR;
	extern float gRes, gBias[3]; // scale resolutions per LSB for the sensors

#ifdef __cplusplus
}
#endif

#endif