We have ported the Adafruit SSD1306 and GFX libraries to work with Nordic nRF52832.

![bluey OLED](bluey-OLED_sm.jpg)

