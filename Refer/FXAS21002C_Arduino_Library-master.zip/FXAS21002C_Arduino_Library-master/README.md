FXAS21002C-Arduino [![Build Status](https://travis-ci.org/sabas1080/FXAS21002C_Arduino_Library.svg?branch=master)](https://travis-ci.org/sabas1080/FXAS21002C_Arduino_Library)
================== 

Arduino library for the FXAS21002C 3-Axis Digital Angular Rate Gyroscope
# Install

## Recommended
1. Download the github repo
2. Extract the file into your Arduino's library folder
3. Include & Enjoy!

## Command-line
* Navigate to the Arduino library folder
* Clone this github repo into the FXAS21002C folder
* Include code into your project and enjoy!

# Usage
To be continued...

By Andres Sabas Agosto 2015
for BuildNight Instructables of The Inventor's House and Freescale
