.. _using_the_lwm2m_carrier_library:

Using the carrier library
#########################

.. |application_sample_name| replace:: Asset Tracker v2 application

.. include:: /includes/lwm2m_carrier_library.txt
