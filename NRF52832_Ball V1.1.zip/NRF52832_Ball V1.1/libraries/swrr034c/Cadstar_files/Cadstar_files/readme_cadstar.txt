   
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X                                                                           X
X   Artwork and documentation done by: Texas Instruments                    X
X                                                                           X
X   Company: Texas Instrument Norway Gaustadalleen 21    0349 OSLO          X
X                                                                           X
X                                                                           X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PROJECT : 02562
PCB NAME : CC2430DB
REVISION: 1.4
DATE: 2007-05-14

FILE NAME            	DESCRIPTION                               		FILE TYPE
-------------------------------------------------------------------------------------------
***DESIGN FILES:
CC2430DB_1_4.SCM        CADSTAR SCHEMATIC FILE                                  BINARY
CC2430DB_1_3.PCB       	CADSTAR PCB FILE                                        BINARY
CC2430DB_1_3.CPA       	CADSTAR PCB ARCHIVE FILE                                ASCII
CC2430DB_1_4.CSA       	CADSTAR SCHEMATIC ARCHIVE FILE                          ASCII

README_CADSTAR.TXT      THIS FILE                                               ASCII

END.
